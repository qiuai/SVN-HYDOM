//
//  characteristicMarketView.h
//  HD_Car
//
//  Created by xingso on 15/7/9.
//  Copyright (c) 2015年 HD_CyYihan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface characteristicMarketView : UIView

@end

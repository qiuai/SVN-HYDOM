//
//  characteristicMarketView.m
//  HD_Car
//
//  Created by xingso on 15/7/9.
//  Copyright (c) 2015年 HD_CyYihan. All rights reserved.
//

#import "characteristicMarketView.h"

@implementation characteristicMarketView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
